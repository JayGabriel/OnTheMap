//
//  Constants.swift
//  OnTheMap
//
//  Created by Jay Gabriel on 10/8/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import UIKit

struct Constants {
    
    // MARK: Parse Constants
    struct ParseParameterKeys {
        static let ParseURL = "https://parse.udacity.com/parse/classes/StudentLocation?limit=100"
        static let Limit = "limit"
        static let ApplicationId = "X-Parse-Application-Id"
        static let APIKey = "X-Parse-REST-API-Key"
        static let Content_Type =  "Content-Type"
    }
    
    struct ParseParameterValues {
        static let ApplicationId = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
        static let Limit = "100"
        static let APIKey = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
        static let ApplicationType = "application/json"
    }
    
    struct ParseResponseKeys {
        static let Results = "results"
        static let ResultsDictionaryIndex = 0
        static let FirstName = "firstName"
        static let LastName = "lastName"
        static let Latitude = "latitude"
        static let Longitude = "longitude"
        static let MediaURL = "mediaURL"
        static let UpdatedAt = "updatedAt"
    }
    
    // MARK: Udacity Constants
    struct UdacityParameterKeys {
        static let SessionURL = "https://www.udacity.com/api/session"
        static let SignUpURL = "https://auth.udacity.com/sign-up"
        static let UserInfo =  "https://www.udacity.com/api/users"
        static let Accept = "Accept"
        static let Content_Type =  "Content-Type"
    }
    
    struct UdacityParameterValues {
        static let ApplicationType = "application/json"
        static let CookieName = "XSRF-TOKEN"
        static let CookieToken = "X-XSRF-TOKEN"
    }
    
    struct UdacityResponseKeys {
        static let Session = "session"
        static let User = "user"
        static let Results = "results"
        static let Id = "id"
        static let Account = "account"
        static let Key = "key"
        static let FirstName = "firstName"
        static let LastName = "lastName"
        static let Latitude = "latitude"
        static let Longitude = "longitude"
        static let MediaURL = "mediaURL"
        static let InfoFirstName = "first_name"
        static let InfoLastName = "last_name"
    }
    
    struct APIMethodType {
        static let Post = "POST"
        static let Put = "PUT"
        static let Delete = "DELETE"
    }
    
    struct AlertMessages {
        static let Success = "Success"
        static let LoadingSuccess = "Locations successfully loaded."
        static let PostSuccess = "Location successfully posted."
        static let LogoutSuccess = "You have been logged out successfully."
        static let Error = "Error"
        static let ParseError = "Could not load information."
        static let urlError = "The supplied URL is invaid."
        static let cityError = "Could not find the specified city."
        static let textFieldError = "Please enter text in both fields."
        static let PostError = "The location could not be posted."
        static let Dismiss = "Dismiss"
    }
}

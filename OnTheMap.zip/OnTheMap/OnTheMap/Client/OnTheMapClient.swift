//
//  OnTheMapClient.swift
//  OnTheMap
//
//  Created by Jay Gabriel on 10/8/17.
//  Copyright © 2017 Jay Gabriel. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class OnTheMapClient {
    
    static let OTMClient = OnTheMapClient()
    
    // MARK: Properties
    var sharedSession = URLSession.shared
    var sessionID: String? = nil
    var userKey: String? = nil
    
    // MARK: User information
    var firstName: String? = nil
    var lastName: String? = nil
    var mapString: String? = nil
    var mediaURL: String? = nil
    var latitude: Double? = nil
    var longitude: Double? = nil
    
    // MARK: Udacity students information
    var studentStore = StudentStore()
    
    // MARK: - Network requests
    func getSessionID(email: String, password: String, completionHandlerForLogin: @escaping (_ success: Bool, _ errorString: String?) -> Void) {
        
        let request = NSMutableURLRequest(url: URL(string: Constants.UdacityParameterKeys.SessionURL)!)
        request.httpMethod = Constants.APIMethodType.Post
        request.addValue(Constants.UdacityParameterValues.ApplicationType, forHTTPHeaderField:  Constants.UdacityParameterKeys.Accept)
        request.addValue(Constants.UdacityParameterValues.ApplicationType, forHTTPHeaderField: Constants.UdacityParameterKeys.Content_Type)
        request.httpBody = "{\"udacity\": {\"username\": \"\(email)\", \"password\": \"\(password)\"}}".data(using: String.Encoding.utf8)
        
        // Create the task
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            // Handle error
            if let e = error {
                completionHandlerForLogin(false, e.localizedDescription)
                return
            }
            
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range)
            
            // Parse data, handle errors
            guard let dataToParse = newData else {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            
            var parsedResult: [String:AnyObject]!
            do {
                parsedResult = try JSONSerialization.jsonObject(with: dataToParse, options: .allowFragments) as! [String:AnyObject]
            } catch {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            
            if let e = parsedResult["error"] {
                completionHandlerForLogin(false, e as? String)
                return
            }
            
            // Set the sessionID
            guard let sessionDicitonary = parsedResult[Constants.UdacityResponseKeys.Session] as? [String:AnyObject] else {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            guard let sessionID = sessionDicitonary[Constants.UdacityResponseKeys.Id] as? String else {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            self.sessionID = sessionID
            
            // Set all user information
            guard let accountDictionary = parsedResult[Constants.UdacityResponseKeys.Account] as? [String:AnyObject] else {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            guard let userKey = accountDictionary[Constants.UdacityResponseKeys.Key] as? String else {
                completionHandlerForLogin(false, Constants.AlertMessages.ParseError)
                return
            }
            
            // Set user key and name
            self.userKey = userKey
            self.getName()
            
            completionHandlerForLogin(true, nil)
        }
        task.resume()
    }
    
    func loadStudentLocations(completionHandlerForLoading: @escaping (_ success: Bool, _ errorString: String?) -> Void) {
        
        // Empty the student array if it has elements
        if (studentStore.students.count > 0) {
            studentStore.removeAllStudents()
        }
        
        let request = NSMutableURLRequest(url: URL(string: Constants.ParseParameterKeys.ParseURL)!)
        request.addValue(Constants.ParseParameterValues.ApplicationId, forHTTPHeaderField: Constants.ParseParameterKeys.ApplicationId)
        request.addValue(Constants.ParseParameterValues.APIKey, forHTTPHeaderField:Constants.ParseParameterKeys.APIKey )
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest) { (data, response, error) in
            
            // Handle error
            if let e = error {
                completionHandlerForLoading(false, e.localizedDescription)
                return
            }
            
            // Parse data, handle errors
            guard let dataToParse = data else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError)
                return
            }
            
            var parsedResult: [String:AnyObject]!
            do {
                parsedResult = try JSONSerialization.jsonObject(with: dataToParse, options: .allowFragments) as! [String:AnyObject]
            } catch {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError)
                return
            }
            guard let studentDictionary = parsedResult[Constants.UdacityResponseKeys.Results] as? [AnyObject] else {
                completionHandlerForLoading(false, Constants.AlertMessages.ParseError)
                return
            }
            
            // Iterate over students
            for student in 0..<studentDictionary.count {
                let currentStudent = studentDictionary[student]
                let firstName = currentStudent[Constants.ParseResponseKeys.FirstName] as? String
                let lastName = currentStudent[Constants.ParseResponseKeys.LastName] as? String
                let latitude = currentStudent[Constants.ParseResponseKeys.Latitude] as? Double
                let longitude = currentStudent[Constants.ParseResponseKeys.Longitude] as? Double
                let mediaURL = currentStudent[Constants.ParseResponseKeys.MediaURL] as? String
                let updatedAt = currentStudent[Constants.ParseResponseKeys.UpdatedAt] as? String
                
                var studentInfo = [String:AnyObject]()
                studentInfo[Constants.ParseResponseKeys.FirstName] = firstName as AnyObject
                studentInfo[Constants.ParseResponseKeys.LastName] = lastName as AnyObject
                studentInfo[Constants.ParseResponseKeys.Latitude] = latitude as AnyObject
                studentInfo[Constants.ParseResponseKeys.Longitude] = longitude as AnyObject
                studentInfo[Constants.ParseResponseKeys.MediaURL] = mediaURL as AnyObject
                studentInfo[Constants.ParseResponseKeys.UpdatedAt] = updatedAt as AnyObject
                
                let studentObject = Student(studentInfo: studentInfo)
                self.studentStore.addStudent(student: studentObject)
            }
            
            // Sort by most recently updated
            self.studentStore.sortStudents()

            // Update main
            completionHandlerForLoading(true, nil)
        }
        task.resume()
    }
    
    func getName() {
        let request = URLRequest(url: URL(string: Constants.UdacityParameterKeys.UserInfo+"/\(userKey!)")!)
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            // Handle error
            if let e = error {
                printMessage(title: Constants.AlertMessages.Error, message: e.localizedDescription)
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range)
            
            // Parse data, handle errors
            let userDictionary: [String:AnyObject]!
            do {
                userDictionary = try JSONSerialization.jsonObject(with: newData!, options: .allowFragments) as? [String:AnyObject]
            } catch {
                printMessage(title: Constants.AlertMessages.Error, message: Constants.AlertMessages.ParseError)
                return
            }
            
            guard let userInfo = userDictionary[Constants.UdacityResponseKeys.User] as? [String:AnyObject] else {
                printMessage(title: Constants.AlertMessages.Error, message: Constants.AlertMessages.ParseError)
                return
            }
            guard let firstName = userInfo[Constants.UdacityResponseKeys.InfoFirstName] as? String else {
                printMessage(title: Constants.AlertMessages.Error, message: Constants.AlertMessages.ParseError)
                return
            }
            guard let lastName = userInfo[Constants.UdacityResponseKeys.InfoLastName] as? String else {
                printMessage(title: Constants.AlertMessages.Error, message: Constants.AlertMessages.ParseError)
                return
            }
            
            // Set the user's name properties
            self.firstName = firstName
            self.lastName = lastName
        }
        task.resume()
    }
    
    func addLocation(completionHandlerForPost: @escaping (_ success: Bool, _ errorString: String?) -> Void) {

        let request = NSMutableURLRequest(url: URL(string: Constants.ParseParameterKeys.ParseURL)!)
        request.httpMethod = Constants.APIMethodType.Post
        request.addValue(Constants.ParseParameterValues.ApplicationId, forHTTPHeaderField: Constants.ParseParameterKeys.ApplicationId)
        request.addValue(Constants.ParseParameterValues.APIKey, forHTTPHeaderField: Constants.ParseParameterKeys.APIKey)
        request.addValue(Constants.ParseParameterValues.ApplicationType, forHTTPHeaderField: Constants.ParseParameterKeys.Content_Type)
        
        request.httpBody = "{\"uniqueKey\": \"\(self.userKey!)\", \"firstName\": \"\(self.firstName!)\", \"lastName\": \"\(self.lastName!)\",\"mapString\": \"\(self.mapString!)\", \"mediaURL\": \"\(self.mediaURL!)\",\"latitude\": \(self.latitude!), \"longitude\": \(self.longitude!)}".data(using: String.Encoding.utf8)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            // Handle error
            if let _ = error {
                completionHandlerForPost(false, Constants.AlertMessages.PostError)
            }
            completionHandlerForPost(true, nil)
        }
        task.resume()
    }
    
    func logout() {
        // Reset all user properties
        resetProperties()
        
        let request = NSMutableURLRequest(url: URL(string: Constants.UdacityParameterKeys.SessionURL)!)
        request.httpMethod = Constants.APIMethodType.Delete
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == Constants.UdacityParameterValues.CookieName { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: Constants.UdacityParameterValues.CookieToken)
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            // Handle error
            if let e = error {
                performUIUpdatesOnMain {
                    printMessage(title: Constants.AlertMessages.Error, message: e.localizedDescription)
                }
                return
            }
            
            // Present logout success message
            performUIUpdatesOnMain {
                 printMessage(title: Constants.AlertMessages.Success, message: Constants.AlertMessages.LogoutSuccess)
            }
        }
        task.resume()
    }
    
    func resetProperties() {
        sessionID = nil
        userKey = nil
        firstName = nil
        lastName = nil
        mapString = nil
        mediaURL = nil
        latitude = nil
        longitude = nil
        studentStore.students.removeAll()
    }
}
